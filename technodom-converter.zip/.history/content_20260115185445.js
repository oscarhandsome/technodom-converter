function convertPrice() {
  const priceEl = document.querySelector(
    "p.Typography.ProductPricesVariantB_accented__n2rtH"
  );

  if (!priceEl || priceEl.dataset.converted) return;

  const kzt = Number(priceEl.textContent.replace(/\D/g, ""));
  if (!kzt) return;

  const url = `https://api.frankfurter.app/latest?from=KZT&to=USD,RUB`;

  fetch("https://api.frankfurter.app/latest?from=KZT&to=USD,RUB")
    .then((r) => r.json())
    .then((data) => {
      if (!data.rates) return;

      const usd = (kzt * data.rates.USD).toFixed(2);
      const rub = (kzt * data.rates.RUB).toFixed(2);

      const box = document.createElement("div");
      box.className = "td-converter-box";
      box.innerHTML = `
      💵 ${usd} USD<br>
      ₽ ${rub} RUB
    `;

      priceEl.after(box);
      priceEl.dataset.converted = "1";
    })
    .catch((err) => console.error("Currency error", err));
}

// следим за изменениями страницы
const observer = new MutationObserver(convertPrice);
observer.observe(document.body, { childList: true, subtree: true });

// первый запуск
convertPrice();
