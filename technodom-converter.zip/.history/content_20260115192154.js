(async function () {
  const elParentBlock = document.querySelector(
    ".ProductPricesVariantB_block__hevXI"
  );
  // Найти элемент с ценой
  const priceEl = document.querySelector(
    "p.Typography.ProductPricesVariantB_accented__n2rtH"
  );

  if (!priceEl) return; // если нет цены — выходим

  // Получить чистое число
  const text = priceEl.textContent.trim();
  const kztPrice = Number(text.replace(/\D/g, ""));

  if (!kztPrice || isNaN(kztPrice)) return;

  // Получаем курсы
  async function getRates() {
    try {
      const res = await fetch("https://open.er-api.com/v6/latest/KZT");
      const data = await res.json();
      return {
        usd: data.rates.USD,
        rub: data.rates.RUB,
      };
    } catch (e) {
      console.error("Ошибка получения курсов:", e);
      return null;
    }
  }

  const rates = await getRates();
  if (!rates) return;

  const usdPrice = (kztPrice * rates.usd).toFixed(2);
  const rubPrice = (kztPrice * rates.rub).toFixed(2);

  // Создаём блок
  const container = document.createElement("div");
  container.className = "td-converter-box";

  const basicStylesFromTechnodom =
    "Typography Typography__L Typography__L_Bold";

  container.innerHTML = `
    <div class="${basicStylesFromTechnodom}">💵 <strong>${usdPrice} USD</strong></div>
    <div class="${basicStylesFromTechnodom}">₽ <strong>${rubPrice} RUB</strong></div>
  `;

  // Вставляем после цены
  elParentBlock.after(container);
})();
