let debounceTimer = null;
let cachedRates = null;
let cachedAt = 0;
const CACHE_TTL = 60 * 60 * 1000; // 1 час (можно 24ч)

function formatPrice(value) {
  return value
    .toLocaleString("ru-RU", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    })
    .replace(/\s/g, "&nbsp;");
}

async function convertProductPagePrice() {
  const priceBlock = document.querySelector(
    ".ProductPricesVariantB_block__hevXI"
  );
  const priceEl = priceBlock?.querySelector(
    "p.Typography.Typography__Heading.Typography__Heading_H1"
  );

  if (!priceBlock || !priceEl) return;

  const priceText = priceEl.textContent;
  if (priceEl.dataset.lastPrice === priceText) return;
  priceEl.dataset.lastPrice = priceText;

  const kzt = Number(priceText.replace(/\D/g, ""));
  if (!kzt) return;

  const rates = await getRates();
  if (!rates) return;

  const oldBox = priceBlock.parentElement.querySelector(".td-converter-box");
  if (oldBox) oldBox.remove();

  const box = document.createElement("div");
  box.className =
    "td-converter-box Typography Typography__L Typography__L_Bold";
  box.innerHTML = `
    💵 ${formatPrice(kzt * rates.USD)}&nbsp;USD<br>
    ₽ ${formatPrice(kzt * rates.RUB)}&nbsp;RUB
  `;

  priceBlock.after(box);
}
