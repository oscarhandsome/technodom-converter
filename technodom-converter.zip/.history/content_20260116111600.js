let debounceTimer = null;
let cachedRates = null;
let cachedAt = 0;
const CACHE_TTL = 60 * 60 * 1000; // 1 час (можно 24ч)

function formatPrice(value) {
  return value
    .toLocaleString("ru-RU", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    })
    .replace(/\s/g, "&nbsp;");
}

async function getRates() {
  const now = Date.now();

  if (cachedRates && now - cachedAt < CACHE_TTL) {
    return cachedRates;
  }

  const r = await fetch("https://open.er-api.com/v6/latest/KZT");
  const data = await r.json();
  if (data.result !== "success") return null;

  cachedRates = data.rates;
  cachedAt = now;
  return cachedRates;
}

async function convertProductPagePrice() {
  const elParentBlock = document.querySelector(
    ".ProductPricesVariantB_block__hevXI"
  );

  const priceEl = document.querySelector(
    "p.Typography.Typography__Heading.Typography__Heading_H1"
  );

  if (!priceEl || !elParentBlock) return;

  const priceText = priceEl.textContent;
  if (priceEl.dataset.lastPrice === priceText) return;
  priceEl.dataset.lastPrice = priceText;

  const kzt = Number(priceText.replace(/\D/g, ""));
  if (!kzt) return;

  const rates = await getRates();
  if (!rates) return;

  const oldBox = elParentBlock.parentElement.querySelector(".td-converter-box");
  if (oldBox) oldBox.remove();

  const box = document.createElement("div");
  box.className =
    "td-converter-box Typography Typography__L Typography__L_Bold";
  box.innerHTML = `
    💵 ${formatPrice(kzt * rates.USD)}&nbsp;USD<br>
    ₽ ${formatPrice(kzt * rates.RUB)}&nbsp;RUB
  `;

  elParentBlock.after(box);
}

async function convertCatalogPrices() {
  const priceEls = document.querySelectorAll('p[data-testid="product-price"]');

  if (!priceEls.length) return;

  const rates = await getRates();
  if (!rates) return;

  priceEls.forEach((priceEl) => {
    if (priceEl.dataset.converted) return;

    const kzt = Number(priceEl.textContent.replace(/\D/g, ""));
    if (!kzt) return;

    const box = document.createElement("div");
    box.className =
      "td-converter-box Typography Typography__XS Typography__XS_Regular";
    box.innerHTML = `
      💵 ${formatPrice(kzt * rates.USD)}&nbsp;USD<br>
      ₽ ${formatPrice(kzt * rates.RUB)}&nbsp;RUB
    `;

    priceEl.after(box);
    priceEl.dataset.converted = "1";
  });
}

const observer = new MutationObserver(() => {
  clearTimeout(debounceTimer);
  debounceTimer = setTimeout(() => {
    convertProductPagePrice();
    convertCatalogPrices();
  }, 300);
});

observer.observe(document.body, {
  childList: true,
  subtree: true,
});

// первый запуск
convertProductPagePrice();
convertCatalogPrices();
