function convertPrice() {
  const priceEl = document.querySelector(
    "p.Typography.ProductPricesVariantB_accented__n2rtH"
  );

  if (!priceEl || priceEl.dataset.converted) return;

  const kzt = Number(priceEl.textContent.replace(/\D/g, ""));
  if (!kzt) return;

  fetch("https://open.er-api.com/v6/latest/KZT")
    .then((r) => r.json())
    .then((data) => {
      if (data.result !== "success") return;

      const usdRate = data.rates.USD;
      const rubRate = data.rates.RUB;

      if (!usdRate || !rubRate) return;

      const usd = (kzt * usdRate).toFixed(2);
      const rub = (kzt * rubRate).toFixed(2);

      const box = document.createElement("p");
      box.className = "td-converter-box";
      box.innerHTML = `
      💵 ${usd} USD<br>
      ₽ ${rub} RUB
    `;

      priceEl.after(box);
      priceEl.dataset.converted = "1";
    })
    .catch((err) => console.error("Currency API error:", err));
}

// следим за изменениями страницы
const observer = new MutationObserver(convertPrice);
observer.observe(document.body, { childList: true, subtree: true });

// первый запуск
convertPrice();
