function convertPrice() {


  const priceEl = document.querySelector(
    "p.Typography.Typography__Heading.Typography__Heading_H1"
  );

  if (!priceEl || priceEl.dataset.converted) return;

  const kzt = Number(priceEl.textContent.replace(/\D/g, ""));
  if (!kzt) return;

  fetch("https://open.er-api.com/v6/latest/KZT")
    .then((r) => r.json())
    .then((data) => {
      const usd = (kzt * data.rates.USD).toFixed(2);
      const rub = (kzt * data.rates.RUB).toFixed(2);

      

      const box = document.createElement("div");
      box.className = "td-converter-box";
      box.innerHTML = `
        <div class="${basicStylesFromTechnodom}">
        💵 ${usd} USD<br>
        ₽ ${rub} RUB
        </div>
      `;

      elParentBlock.after(box);
      elParentBlock.dataset.converted = "1";
    });
}

// следим за изменениями страницы
const observer = new MutationObserver(convertPrice);
observer.observe(document.body, { childList: true, subtree: true });

// первый запуск
convertPrice();




=========


let debounceTimer = null;

function convertPrice() {
  const elParentBlock = document.querySelector(
    ".ProductPricesVariantB_block__hevXI"
  );

  const priceEl = document.querySelector(
    "p.Typography.Typography__Heading.Typography__Heading_H1"
  );

  const basicStylesFromTechnodom =
        "Typography Typography__L Typography__L_Bold";

  if (!priceEl) return;

  const priceText = priceEl.textContent;
  const kzt = Number(priceText.replace(/\D/g, ""));
  if (!kzt) return;

  // если цена не изменилась — ничего не делаем
  if (priceEl.dataset.lastPrice === priceText) return;
  priceEl.dataset.lastPrice = priceText;

  // удаляем старый блок, если был
  const oldBox = priceEl.parentElement.querySelector(".td-converter-box");
  if (oldBox) oldBox.remove();

  fetch("https://open.er-api.com/v6/latest/KZT")
    .then(r => r.json())
    .then(data => {
      if (data.result !== "success") return;

      const usd = (kzt * data.rates.USD).toFixed(2);
      const rub = (kzt * data.rates.RUB).toFixed(2);

      const box = document.createElement("div");
      box.className = "td-converter-box";
      box.innerHTML = `
        <div class="${basicStylesFromTechnodom}">
        💵 ${usd} USD<br>
        ₽ ${rub} RUB
        </div>
      `;

      elParentBlock.after(box);
    });
}

// debounce для MutationObserver
const observer = new MutationObserver(() => {
  clearTimeout(debounceTimer);
  debounceTimer = setTimeout(convertPrice, 300);
});

observer.observe(document.body, {
  childList: true,
  subtree: true
});

// первый запуск
convertPrice();
