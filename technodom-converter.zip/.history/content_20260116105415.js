let debounceTimer = null;
let cachedRates = null;
let cachedAt = 0;

async function getRates() {
  const now = Date.now();
  if (cachedRates && now - cachedAt < 86400000) {
    return cachedRates;
  }

  const r = await fetch("https://open.er-api.com/v6/latest/KZT");
  const data = await r.json();
  if (data.result !== "success") return null;

  cachedRates = data.rates;
  cachedAt = now;
  return cachedRates;
}

function formatPrice(value, locale = "ru-RU") {
  return value
    .toLocaleString(locale, {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    })
    .replace(/\s/g, "&nbsp;");
}

async function convertProductPagePrice() {
  const elParentBlock = document.querySelector(
    ".ProductPricesVariantB_block__hevXI"
  );

  const priceEl = document.querySelector(
    "p.Typography.Typography__Heading.Typography__Heading_H1"
  );

  if (!priceEl || !elParentBlock) return;

  const priceText = priceEl.textContent;
  if (priceEl.dataset.lastPrice === priceText) return;
  priceEl.dataset.lastPrice = priceText;

  const kzt = Number(priceText.replace(/\D/g, ""));
  if (!kzt) return;

  const rates = await getRates();
  if (!rates) return;

  const oldBox = elParentBlock.parentElement.querySelector(".td-converter-box");
  if (oldBox) oldBox.remove();

  const box = document.createElement("div");
  box.className =
    "td-converter-box Typography Typography__L Typography__L_Bold";
  box.innerHTML = `
    💵 ${formatPrice(kzt * rates.USD)}&nbsp;USD<br>
    ₽ ${formatPrice(kzt * rates.RUB)}&nbsp;RUB
  `;

  elParentBlock.after(box);
}
// debounce для MutationObserver
const observer = new MutationObserver(() => {
  clearTimeout(debounceTimer);
  debounceTimer = setTimeout(convertPrice, 300);
});

observer.observe(document.body, {
  childList: true,
  subtree: true,
});

// первый запуск
convertPrice();
